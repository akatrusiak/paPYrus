# PaPYrus

a lightweigh text file searcher and previewer with an interface

## installation

you may need to install tkinter to your python. To first check if tkinter is insalled try:
```
python3 -m tkinter
```
and you should see a tkinter window open. If it does, continue with pip install. If it does not, then:
```
sudo apt-get install python3-tk
```
if you're on debian based unix, if not you're smart enough to google how to install it. 

Then:
```
pip install 
```
