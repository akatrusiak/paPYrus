#Allowed FIle extensions
FILE_TYPES = {".txt", ".md", ""}

#text preview length
PREVIEW_LENGTH = 200